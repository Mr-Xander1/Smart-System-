// ---------------------------------------------------------------------------
// Global Ocean Risk Zones
// ---------------------------------------------------------------------------
// Replaces the old single-basin "Atlantic heatwave monitoring grid" (a static
// 2024 CSV export) with a curated set of real coastal/open-ocean zones spread
// across every ocean basin. Each zone is polled live (see
// hooks/useGlobalRiskZones.js) against the free, key-less Open-Meteo Marine
// and Weather APIs, so "all risk zones" means every major fishing/shipping
// basin on Earth — not just the Atlantic.
// ---------------------------------------------------------------------------

export const OCEAN_ZONES = [
  { key: "dakar", name: "Dakar Coast (Senegal)", region: "Eastern Atlantic", lat: 14.5, lon: -17.5 },
  { key: "lagos", name: "Lagos Coast (Gulf of Guinea)", region: "Eastern Atlantic", lat: 4.0, lon: 4.0 },
  { key: "fortaleza", name: "Fortaleza Coast (NE Brazil)", region: "Western Atlantic", lat: -3.7, lon: -38.5 },
  { key: "capetown", name: "Cape Town / Cape of Good Hope", region: "South Atlantic", lat: -34.0, lon: 18.0 },
  { key: "biscay", name: "Bay of Biscay", region: "North Atlantic", lat: 46.0, lon: -4.0 },
  { key: "gulfmexico", name: "Gulf of Mexico", region: "North Atlantic", lat: 25.0, lon: -90.0 },
  { key: "caribbean", name: "Caribbean Sea", region: "Western Atlantic", lat: 15.0, lon: -70.0 },
  { key: "mediterranean", name: "Ligurian Sea (Mediterranean)", region: "Mediterranean", lat: 43.0, lon: 8.0 },
  { key: "arabiansea", name: "Arabian Sea", region: "Indian Ocean", lat: 15.0, lon: 65.0 },
  { key: "bayofbengal", name: "Bay of Bengal", region: "Indian Ocean", lat: 15.0, lon: 88.0 },
  { key: "andamansea", name: "Andaman Sea", region: "Indian Ocean", lat: 10.0, lon: 96.0 },
  { key: "southchinasea", name: "South China Sea", region: "West Pacific", lat: 12.0, lon: 114.0 },
  { key: "philippinesea", name: "Philippine Sea", region: "West Pacific", lat: 15.0, lon: 130.0 },
  { key: "eastchinasea", name: "East China Sea", region: "West Pacific", lat: 30.0, lon: 125.0 },
  { key: "coralsea", name: "Coral Sea (Great Barrier Reef)", region: "South Pacific", lat: -18.0, lon: 149.0 },
  { key: "californiacoast", name: "California Current", region: "NE Pacific", lat: 36.0, lon: -122.0 },
  { key: "gulfofalaska", name: "Gulf of Alaska", region: "North Pacific", lat: 57.0, lon: -145.0 },
  { key: "perucurrent", name: "Peru / Humboldt Current", region: "SE Pacific", lat: -12.0, lon: -77.5 },
  { key: "redsea", name: "Red Sea", region: "Indian Ocean", lat: 20.0, lon: 38.0 },
  { key: "persiangulf", name: "Persian Gulf", region: "Indian Ocean", lat: 26.5, lon: 51.5 },
  { key: "javasea", name: "Java Sea (Indonesia)", region: "West Pacific", lat: -6.0, lon: 110.0 },
  { key: "southernocean", name: "Drake Passage (Southern Ocean)", region: "Southern Ocean", lat: -58.0, lon: -65.0 },
];

export const OCEAN_ZONE_KEYS = OCEAN_ZONES.map((z) => z.key);
