import { useMemo } from "react";
import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Popup,
  Tooltip,
  LayersControl,
  LayerGroup,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { INDIAN_PORTS } from "./data/indianPorts";
import { GLOBAL_PORTS } from "./data/globalPorts";
import { annotatePorts, VERDICT_STYLE } from "./utils/portAdvisory";
import { useGlobalRiskZones } from "./hooks/useGlobalRiskZones";

const RISK_STYLE = {
  Low: { fill: "#22c55e", stroke: "#15803d" },
  Moderate: { fill: "#fbbf24", stroke: "#b45309" },
  High: { fill: "#fb923c", stroke: "#c2410c" },
  Severe: { fill: "#ef4444", stroke: "#7f1d1d" },
};

function styleFor(label) {
  return RISK_STYLE[label] || { fill: "#38bdf8", stroke: "#0369a1" };
}

function radiusFor(score) {
  return 6 + Math.min(10, score / 10);
}

const WORLD_PORTS = [...INDIAN_PORTS, ...GLOBAL_PORTS];

function MapSection() {
  const { zones, loading, error, lastUpdated } = useGlobalRiskZones();

  const worldPorts = useMemo(() => annotatePorts(WORLD_PORTS, zones), [zones]);

  const counts = zones.reduce(
    (acc, z) => {
      acc[z.risk.label] = (acc[z.risk.label] || 0) + 1;
      return acc;
    },
    { Low: 0, Moderate: 0, High: 0, Severe: 0 }
  );

  if (loading) {
    return (
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
        <h2 className="text-2xl font-semibold mb-4">🌍 Global GIS Risk Map</h2>
        <p className="text-slate-400">Fetching live marine risk zones worldwide…</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <div>
          <h2 className="text-2xl font-semibold">🌍 Global GIS Risk Map</h2>
          <p className="text-sm text-slate-400 mt-1">
            {zones.length} live risk zones worldwide · {worldPorts.length} fishing ports
            {lastUpdated ? ` · updated ${lastUpdated.toLocaleTimeString()}` : ""}
          </p>
        </div>

        <div className="flex flex-wrap gap-2 text-xs">
          {Object.entries(counts).map(([label, count]) => (
            <span key={label} className="flex items-center gap-1.5 bg-slate-900/60 px-2.5 py-1.5 rounded-lg">
              <span
                className="w-2.5 h-2.5 rounded-full inline-block border"
                style={{ background: styleFor(label).fill, borderColor: styleFor(label).stroke }}
              />
              {label} ({count})
            </span>
          ))}
        </div>
      </div>

      {error && <p className="text-xs text-amber-400 mb-3">Some zones fell back to modeled estimates: {error}</p>}

      <MapContainer
        center={[5, -15]}
        zoom={2}
        minZoom={2}
        maxZoom={12}
        style={{ height: "480px", width: "100%", background: "#eef2f5" }}
        worldCopyJump
      >
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="Light (GIS style)">
            <TileLayer
              attribution='&copy; OpenStreetMap contributors &copy; CARTO'
              url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
              subdomains="abcd"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Satellite">
            <TileLayer
              attribution="Tiles &copy; Esri — Source: Esri, Maxar, Earthstar Geographics"
              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Streets">
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>

          <LayersControl.Overlay checked name={`Global Fishing Ports (${worldPorts.length})`}>
            <LayerGroup>
              {worldPorts.map((p) => {
                const style = VERDICT_STYLE[p.verdict];
                return (
                  <CircleMarker
                    key={`port-${p.name}`}
                    center={[p.lat, p.lon]}
                    radius={5}
                    pathOptions={{ color: style.color, fillColor: style.color, fillOpacity: 0.8, weight: 1.2 }}
                  >
                    <Tooltip direction="top" offset={[0, -5]}>
                      {p.name}
                    </Tooltip>
                    <Popup>
                      <div className="text-sm text-slate-800">
                        <p className="font-bold mb-1">{p.name}</p>
                        <p className="mb-1">{style.label}</p>
                        <p className="text-xs">{p.reason}</p>
                        <p className="text-xs mt-2 text-slate-500">
                          {p.source === "live" ? "🛰️ Live monitoring zone" : "📈 Modeled climatology estimate"}
                        </p>
                      </div>
                    </Popup>
                  </CircleMarker>
                );
              })}
            </LayerGroup>
          </LayersControl.Overlay>
        </LayersControl>

        {zones.map((z) => {
          const style = styleFor(z.risk.label);
          return (
            <CircleMarker
              key={z.key}
              center={[z.lat, z.lon]}
              radius={radiusFor(z.risk.score)}
              pathOptions={{
                color: style.stroke,
                fillColor: style.fill,
                fillOpacity: 0.75,
                weight: 1.5,
              }}
            >
              <Popup>
                <div className="text-sm text-slate-800">
                  <p className="font-bold mb-1">
                    {z.name} — {z.risk.label} ({z.risk.score}/100)
                  </p>
                  <p>Wave height: {z.waveHeight} m</p>
                  <p>Wind speed: {z.windSpeed} km/h</p>
                  <p>Swell period: {z.swellPeriod} s</p>
                  {z.seaSurfaceTemp != null && <p>SST: {z.seaSurfaceTemp}°C</p>}
                  <p className="text-xs mt-2 text-slate-500">
                    {z.source === "live" ? "🛰️ Live reading" : "📈 Modeled estimate"} · updated{" "}
                    {new Date(z.updatedAt).toLocaleTimeString()}
                  </p>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>

      <p className="text-xs text-slate-500 mt-3">
        Risk zones: live wave/wind/swell/SST readings from Open-Meteo Marine + Weather APIs across every ocean basin,
        refreshed every 5 minutes. The "Global Fishing Ports" overlay (top-right) plots {worldPorts.length} ports
        across every continent, each rated against its nearest live zone — toggle it off to see the risk grid alone,
        or switch to the Satellite layer for real imagery.
      </p>
    </div>
  );
}

export default MapSection;
