import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { OCEAN_ZONES } from "../data/oceanZones";
import { computeRisk } from "../utils/riskEngine";
import { baselineSST, dayOfYear, estimatePortConditions } from "../utils/marineClimatology";

// ---------------------------------------------------------------------------
// RiskZonesContext
// ---------------------------------------------------------------------------
// Single shared live-data source for the whole app. Polls REAL, key-less
// public marine/weather APIs (Open-Meteo) for every zone in
// data/oceanZones.js and runs each reading through the same transparent risk
// model used everywhere in the app (utils/riskEngine). Every panel — the GIS
// map, globe, satellite view, risk-zone list, prediction panel, safe-harbor
// finder and the chat widget — reads from this one provider instead of
// polling independently.
//
// If a zone's fetch fails (offline, rate-limited, CORS hiccup, etc.) it falls
// back to the physically-motivated seasonal climatology model
// (utils/marineClimatology) for that single zone only, clearly marked
// source: "modeled" instead of source: "live".
// ---------------------------------------------------------------------------

const MARINE_API = "https://marine-api.open-meteo.com/v1/marine";
const FORECAST_API = "https://api.open-meteo.com/v1/forecast";
const REFRESH_MS = 5 * 60 * 1000; // 5 minutes — reasonable for a free public API
const HISTORY_LIMIT = 60;

async function fetchZone(zone) {
  const marineUrl =
    `${MARINE_API}?latitude=${zone.lat}&longitude=${zone.lon}` +
    `&current=wave_height,wave_period,swell_wave_height,swell_wave_period,sea_surface_temperature&timezone=UTC`;
  const forecastUrl =
    `${FORECAST_API}?latitude=${zone.lat}&longitude=${zone.lon}` +
    `&current=wind_speed_10m,wind_gusts_10m,surface_pressure` +
    `&hourly=surface_pressure&past_hours=24&forecast_hours=1&timezone=UTC`;

  const [marineRes, forecastRes] = await Promise.all([fetch(marineUrl), fetch(forecastUrl)]);

  if (!marineRes.ok || !forecastRes.ok) {
    throw new Error(`HTTP ${marineRes.status}/${forecastRes.status}`);
  }

  const marine = await marineRes.json();
  const forecast = await forecastRes.json();

  const waveHeight = marine?.current?.wave_height;
  const swellPeriod = marine?.current?.swell_wave_period ?? marine?.current?.wave_period;
  const sst = marine?.current?.sea_surface_temperature;

  const windSpeed = forecast?.current?.wind_speed_10m;
  const pressures = forecast?.hourly?.surface_pressure || [];
  const pressureDrop =
    pressures.length >= 2 ? Number((pressures[0] - pressures[pressures.length - 1]).toFixed(1)) : 0;

  if (waveHeight == null || windSpeed == null) {
    throw new Error("Incomplete live reading");
  }

  const now = new Date();
  const sstAnomaly = sst != null ? Number((sst - baselineSST(zone.lat, dayOfYear(now))).toFixed(2)) : null;

  return {
    waveHeight: Number(waveHeight.toFixed(2)),
    windSpeed: Number(windSpeed.toFixed(1)),
    pressureDrop: Math.max(0, pressureDrop),
    waterTemp: sstAnomaly != null ? Math.abs(sstAnomaly) : 0.4,
    swellPeriod: swellPeriod != null ? Number(swellPeriod.toFixed(1)) : 9,
    seaSurfaceTemp: sst != null ? Number(sst.toFixed(1)) : null,
    sstAnomaly,
    source: "live",
  };
}

function fallbackZone(zone) {
  const model = estimatePortConditions(zone.lat, zone.lon);
  return {
    waveHeight: model.waveHeight,
    windSpeed: model.windSpeed,
    pressureDrop: model.pressureDrop,
    waterTemp: Math.abs(model.sstAnomaly),
    swellPeriod: model.swellPeriod,
    seaSurfaceTemp: model.sst,
    sstAnomaly: model.sstAnomaly,
    source: "modeled",
  };
}

async function loadZone(zone) {
  let conditions;
  try {
    conditions = await fetchZone(zone);
  } catch {
    conditions = fallbackZone(zone);
  }

  const risk = computeRisk({
    waveHeight: conditions.waveHeight,
    windSpeed: conditions.windSpeed,
    pressureDrop: conditions.pressureDrop,
    waterTemp: conditions.waterTemp,
    swellPeriod: conditions.swellPeriod,
  });

  return { ...zone, ...conditions, risk, updatedAt: new Date().toISOString() };
}

const RiskZonesContext = createContext(null);

export function RiskZonesProvider({ children }) {
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [history, setHistory] = useState([]);
  const mountedRef = useRef(true);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      const results = await Promise.all(OCEAN_ZONES.map(loadZone));
      if (!mountedRef.current) return;
      setZones(results);
      setError(null);
      const now = new Date();
      setLastUpdated(now);
      const liveCount = results.filter((z) => z.source === "live").length;
      const avgScore = results.reduce((s, z) => s + z.risk.score, 0) / results.length;
      const worst = results.reduce((a, b) => (b.risk.score > a.risk.score ? b : a), results[0]);
      setHistory((prev) =>
        [
          ...prev,
          {
            time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            timestamp: now.getTime(),
            avgScore: Number(avgScore.toFixed(1)),
            liveCount,
            worstZone: worst?.name,
            worstScore: worst?.risk.score,
          },
        ].slice(-HISTORY_LIMIT)
      );
    } catch (err) {
      if (mountedRef.current) setError(err.message || "Failed to refresh live risk zones");
    } finally {
      if (mountedRef.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    refresh();
    const id = setInterval(refresh, REFRESH_MS);
    return () => {
      mountedRef.current = false;
      clearInterval(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value = { zones, loading, refreshing, error, lastUpdated, refresh, history };

  return <RiskZonesContext.Provider value={value}>{children}</RiskZonesContext.Provider>;
}

export function useGlobalRiskZones() {
  const ctx = useContext(RiskZonesContext);
  if (!ctx) {
    throw new Error("useGlobalRiskZones must be used within a <RiskZonesProvider>");
  }
  return ctx;
}
