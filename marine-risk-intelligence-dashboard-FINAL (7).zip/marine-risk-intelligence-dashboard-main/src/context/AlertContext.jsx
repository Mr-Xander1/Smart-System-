import { createContext, useContext, useEffect, useRef, useState } from "react";
import { useGlobalRiskZones } from "./RiskZonesContext";

// ---------------------------------------------------------------------------
// AlertContext
// ---------------------------------------------------------------------------
// Alerts are generated from REAL live risk-zone data (RiskZonesContext) —
// every time a refresh comes in, any zone at Moderate/High/Severe risk (or
// that has just crossed into a worse level than its previous reading) is
// turned into an alert. Nothing here is a fabricated/canned message; the
// zone name, risk level and reason all come straight from the live reading.
// ---------------------------------------------------------------------------

const AlertContext = createContext(null);
let idCounter = 1;

function alertsFromZones(zones, prevLevels) {
  const flagged = zones.filter((z) => z.risk.label !== "Low");
  return flagged.map((z) => {
    const prevLevel = prevLevels.current[z.key];
    const worsened = prevLevel && prevLevel !== z.risk.label;
    prevLevels.current[z.key] = z.risk.label;
    return {
      id: idCounter++,
      zone: z.name,
      text: `${z.risk.label} risk (${z.risk.score}/100) — wave ${z.waveHeight} m, wind ${z.windSpeed} km/h${
        worsened ? `, just moved from ${prevLevel}` : ""
      }. ${z.source === "live" ? "Live reading." : "Modeled estimate."}`,
      level: z.risk.label,
      time: new Date(z.updatedAt),
      read: false,
    };
  });
}

export function AlertProvider({ children }) {
  const { zones, lastUpdated } = useGlobalRiskZones();
  const [alerts, setAlerts] = useState([]);
  const prevLevels = useRef({});
  const lastProcessed = useRef(null);

  useEffect(() => {
    if (!zones.length || !lastUpdated) return;
    if (lastProcessed.current === lastUpdated.getTime()) return;
    lastProcessed.current = lastUpdated.getTime();

    const fresh = alertsFromZones(zones, prevLevels).sort((a, b) => b.time - a.time);
    setAlerts((prev) => {
      // Keep read-state of anything the user already saw for the same zone/level.
      const prevReadKeys = new Set(prev.filter((a) => a.read).map((a) => `${a.zone}:${a.level}`));
      const merged = fresh.map((a) => ({ ...a, read: prevReadKeys.has(`${a.zone}:${a.level}`) }));
      return merged.slice(0, 20);
    });
  }, [zones, lastUpdated]);

  const markAllRead = () => setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
  const unreadCount = alerts.filter((a) => !a.read).length;

  return (
    <AlertContext.Provider value={{ alerts, unreadCount, markAllRead }}>
      {children}
    </AlertContext.Provider>
  );
}

export function useAlerts() {
  return useContext(AlertContext);
}
