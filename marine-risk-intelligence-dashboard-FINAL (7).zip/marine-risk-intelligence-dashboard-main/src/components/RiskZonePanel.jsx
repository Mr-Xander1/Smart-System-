import { RefreshCw } from "lucide-react";
import { useGlobalRiskZones } from "../hooks/useGlobalRiskZones";
import { labelColor } from "../utils/riskEngine";

function ZoneRow({ zone }) {
  return (
    <div className="bg-slate-700 rounded-lg p-4 flex justify-between items-center gap-3">
      <div>
        <span className="font-medium">{zone.name}</span>
        <div className="text-[11px] text-slate-400 mt-0.5">
          {zone.region} · {zone.source === "live" ? "🛰️ Live reading" : "📈 Modeled estimate"}
        </div>
      </div>
      <span className="flex items-center gap-2 shrink-0">
        <span className="text-xs text-slate-400">{zone.risk.score}/100</span>
        <span className={labelColor(zone.risk.label)}>{zone.risk.label}</span>
      </span>
    </div>
  );
}

function RiskZonePanel() {
  const { zones, loading, refreshing, error, lastUpdated, refresh } = useGlobalRiskZones();

  const sorted = [...zones].sort((a, b) => b.risk.score - a.risk.score);
  const liveCount = zones.filter((z) => z.source === "live").length;

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg mt-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-semibold">🚨 All Risk Zones</h2>
          <p className="text-xs text-slate-400 mt-1">
            {zones.length} zones tracked worldwide · {liveCount} live right now
            {lastUpdated ? ` · updated ${lastUpdated.toLocaleTimeString()}` : ""}
          </p>
        </div>
        <button
          onClick={refresh}
          disabled={refreshing}
          className="flex items-center gap-1.5 text-xs font-medium text-[#c9a962] hover:text-[#dcc07f] bg-slate-900/60 px-3 py-1.5 rounded-lg disabled:opacity-50 shrink-0"
        >
          <RefreshCw size={13} className={refreshing ? "animate-spin" : ""} /> Refresh
        </button>
      </div>

      {loading ? (
        <p className="text-sm text-slate-400">Fetching live marine conditions worldwide…</p>
      ) : (
        <div className="space-y-3">
          {sorted.map((zone) => (
            <ZoneRow key={zone.key} zone={zone} />
          ))}
        </div>
      )}

      {error && <p className="text-xs text-amber-400 mt-4">Some zones fell back to modeled estimates: {error}</p>}

      <p className="text-xs text-slate-500 mt-4">
        Scores update from live wave height, wind speed, 24h pressure trend, sea-surface-temperature anomaly, and
        swell period (Open-Meteo Marine + Weather APIs), refreshed automatically every 5 minutes.
      </p>
    </div>
  );
}

export default RiskZonePanel;
