import { useEffect, useMemo, useRef, useState } from "react";
import { MessageCircle, X, Send, Loader2 } from "lucide-react";
import { useGlobalRiskZones } from "../context/RiskZonesContext";
import { INDIAN_PORTS } from "../data/indianPorts";
import { GLOBAL_PORTS } from "../data/globalPorts";
import { annotatePorts } from "../utils/portAdvisory";
import { haversineKm } from "../utils/geo";

// ---------------------------------------------------------------------------
// ChatWidget — a small floating assistant icon available on every page.
//
// Every answer is generated from REAL, live data already in the app (the
// same useGlobalRiskZones feed the dashboard runs on) — current risk scores,
// worst zones, live wave/wind readings, and the user's actual nearest
// favorable port via browser geolocation. It never returns a canned/fabricated
// figure: if live data isn't loaded yet it says so instead of guessing.
//
// Wiring this to a hosted LLM (e.g. Claude) would need a small server-side
// proxy to hold the API key — browsers can't call api.anthropic.com directly.
// This widget is the safe, keyless alternative: real numbers, no backend.
// ---------------------------------------------------------------------------

const ALL_PORTS = [...INDIAN_PORTS, ...GLOBAL_PORTS];

function findZoneByName(zones, text) {
  const q = text.toLowerCase();
  return zones.find(
    (z) => q.includes(z.name.toLowerCase()) || q.includes(z.key.toLowerCase()) || q.includes(z.region.toLowerCase())
  );
}

function formatZone(z) {
  return (
    `${z.name} (${z.region}) is currently ${z.risk.label} risk (${z.risk.score}/100). ` +
    `Wave height ${z.waveHeight} m, wind ${z.windSpeed} km/h, swell period ${z.swellPeriod} s` +
    `${z.seaSurfaceTemp != null ? `, SST ${z.seaSurfaceTemp}°C` : ""}. ` +
    `${z.source === "live" ? "🛰️ Live reading" : "📈 Modeled estimate"}, updated ${new Date(z.updatedAt).toLocaleTimeString()}.`
  );
}

function useAssistantReply() {
  const { zones, loading, lastUpdated, history } = useGlobalRiskZones();
  const [locating, setLocating] = useState(false);

  const getReply = (rawText) =>
    new Promise((resolve) => {
      const text = rawText.trim();
      const q = text.toLowerCase();

      if (loading || !zones.length) {
        resolve("I'm still pulling live marine data — one moment, then ask me anything.");
        return;
      }

      // Nearest / safe harbour — uses real browser geolocation, not a guess.
      if (
        q.includes("safe harbour") ||
        q.includes("safe harbor") ||
        q.includes("nearest port") ||
        q.includes("nearest harbour") ||
        q.includes("nearest harbor")
      ) {
        if (!navigator.geolocation) {
          resolve(
            "Your browser doesn't support geolocation, so I can't find your real nearest harbour. Try the Safe Harbours panel in the Fishermen Zone instead."
          );
          return;
        }
        setLocating(true);
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setLocating(false);
            const { latitude, longitude } = pos.coords;
            const annotated = annotatePorts(ALL_PORTS, zones).filter((p) => p.verdict === "Favorable");
            const withDist = annotated
              .map((p) => ({ ...p, d: haversineKm(latitude, longitude, p.lat, p.lon) }))
              .sort((a, b) => a.d - b.d);
            const best = withDist[0];
            if (!best) {
              resolve(
                "I couldn't find a currently favorable port nearby — check the Safe Harbours panel for the full ranked list."
              );
              return;
            }
            resolve(
              `Based on your real-time location, the nearest safe harbour is ${best.name}${
                best.state || best.country ? `, ${best.state || best.country}` : ""
              } — about ${Math.round(best.d)} km away. It's currently rated Favorable.`
            );
          },
          () => {
            setLocating(false);
            resolve(
              "I couldn't get your location (permission denied or timed out). Allow location access and ask again, or open the Safe Harbours panel in the Fishermen Zone."
            );
          },
          { timeout: 8000 }
        );
        return;
      }

      // A specific named zone/region.
      const zone = findZoneByName(zones, q);
      if (zone) {
        resolve(formatZone(zone));
        return;
      }

      // Worst / highest risk right now.
      if (q.includes("worst") || q.includes("highest risk") || q.includes("most dangerous") || q.includes("danger")) {
        const worst = [...zones].sort((a, b) => b.risk.score - a.risk.score)[0];
        resolve(`Right now the highest-risk zone is ${formatZone(worst)}`);
        return;
      }

      // Safest / lowest risk.
      if (q.includes("safest") || q.includes("lowest risk") || q.includes("calmest")) {
        const best = [...zones].sort((a, b) => a.risk.score - b.risk.score)[0];
        resolve(`Right now the calmest zone is ${formatZone(best)}`);
        return;
      }

      // Overview / summary / how many zones.
      if (
        q.includes("how many") ||
        q.includes("overview") ||
        q.includes("summary") ||
        q.includes("all zone") ||
        q.includes("all risk")
      ) {
        const avg = (zones.reduce((s, z) => s + z.risk.score, 0) / zones.length).toFixed(1);
        const severe = zones.filter((z) => z.risk.label === "Severe" || z.risk.label === "High").length;
        const live = zones.filter((z) => z.source === "live").length;
        resolve(
          `I'm tracking ${zones.length} ocean risk zones worldwide (${live} on a live feed right now). Average risk score is ${avg}/100, and ${severe} zone${
            severe === 1 ? "" : "s"
          } ${severe === 1 ? "is" : "are"} at High/Severe risk.` +
            (lastUpdated ? ` Last updated ${lastUpdated.toLocaleTimeString()}.` : "")
        );
        return;
      }

      // Trend.
      if (q.includes("trend") || q.includes("rising") || q.includes("improving") || q.includes("getting worse")) {
        if (history.length < 2) {
          resolve("Not enough live samples yet to describe a trend — check back in a few minutes.");
          return;
        }
        const last = history[history.length - 1];
        const prev = history[Math.max(0, history.length - 4)];
        const delta = Number((last.avgScore - prev.avgScore).toFixed(1));
        resolve(
          `Global average risk has ${
            delta > 1 ? "risen" : delta < -1 ? "fallen" : "stayed roughly flat"
          } (${delta > 0 ? "+" : ""}${delta} pts) over the last few updates. Currently ${last.avgScore}/100.`
        );
        return;
      }

      if (q.includes("wave")) {
        const worst = [...zones].sort((a, b) => b.waveHeight - a.waveHeight)[0];
        resolve(`Largest live wave height right now is ${worst.waveHeight} m at ${worst.name}.`);
        return;
      }
      if (q.includes("wind") || q.includes("storm")) {
        const worst = [...zones].sort((a, b) => b.windSpeed - a.windSpeed)[0];
        resolve(`Strongest live wind right now is ${worst.windSpeed} km/h at ${worst.name}.`);
        return;
      }

      if (q.includes("hi") || q.includes("hello") || q.includes("hey")) {
        resolve(
          'Hi! Ask me things like "worst risk zone", "safe harbour", "trend", or name any ocean zone (e.g. "Bay of Bengal") for its live conditions.'
        );
        return;
      }
      if (q.includes("help") || q === "") {
        resolve(
          "I can tell you: the worst/safest risk zone right now, live conditions for any named ocean zone, your real-time nearest safe harbour, the global risk trend, or an overview of all zones."
        );
        return;
      }

      resolve(
        'I didn\'t catch that. Try: "worst risk zone", "safe harbour", "trend", "overview", or the name of an ocean zone like "Arabian Sea".'
      );
    });

  return { getReply, locating };
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [messages, setMessages] = useState([
    {
      from: "bot",
      text: 'Hi, I\'m the Marine Risk Assistant. I answer from live data — try "worst risk zone" or "safe harbour".',
    },
  ]);
  const { getReply, locating } = useAssistantReply();
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  const send = async (text) => {
    const value = (text ?? input).trim();
    if (!value || sending) return;
    setMessages((m) => [...m, { from: "user", text: value }]);
    setInput("");
    setSending(true);
    const reply = await getReply(value);
    setMessages((m) => [...m, { from: "bot", text: reply }]);
    setSending(false);
  };

  const suggestions = useMemo(() => ["Worst risk zone", "Safe harbour", "Trend", "Overview"], []);

  return (
    <div className="fixed bottom-5 right-5 z-[1000]">
      {open && (
        <div className="mb-3 w-[320px] sm:w-[360px] h-[440px] bg-slate-800 border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          <div className="bg-[#0a141b] px-4 py-3 flex items-center justify-between border-b border-white/10">
            <div>
              <p className="font-semibold text-sm">🌊 Marine Risk Assistant</p>
              <p className="text-[11px] text-slate-400">Live data · no canned answers</p>
            </div>
            <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white">
              <X size={18} />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-3 space-y-3">
            {messages.map((m, i) => (
              <div
                key={i}
                className={
                  "max-w-[85%] rounded-xl px-3 py-2 text-sm leading-snug " +
                  (m.from === "bot" ? "bg-slate-700 text-slate-100" : "bg-[#c9a962] text-[#0a141b] ml-auto font-medium")
                }
              >
                {m.text}
              </div>
            ))}
            {(sending || locating) && (
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Loader2 size={13} className="animate-spin" /> {locating ? "Getting your location…" : "Checking live data…"}
              </div>
            )}
          </div>

          <div className="px-3 pb-2 flex flex-wrap gap-1.5">
            {suggestions.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="text-[11px] bg-slate-900/60 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-full"
              >
                {s}
              </button>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
            className="p-3 border-t border-white/10 flex gap-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about a zone, harbour, trend…"
              className="flex-1 bg-slate-900/60 rounded-lg px-3 py-2 text-sm text-slate-200 placeholder:text-slate-500 outline-none focus:ring-1 focus:ring-[#c9a962]"
            />
            <button
              type="submit"
              disabled={sending}
              className="bg-[#c9a962] text-[#0a141b] rounded-lg px-3 py-2 disabled:opacity-50"
            >
              <Send size={16} />
            </button>
          </form>
        </div>
      )}

      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Open marine risk assistant"
        className="w-14 h-14 rounded-full bg-[#c9a962] text-[#0a141b] shadow-xl flex items-center justify-center hover:scale-105 transition-transform"
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </div>
  );
}
