import Globe from "react-globe.gl";
import { useMemo, useState } from "react";
import { useGlobalRiskZones } from "../hooks/useGlobalRiskZones";
import { INDIAN_PORTS } from "../data/indianPorts";
import { GLOBAL_PORTS } from "../data/globalPorts";
import { annotatePorts, VERDICT_STYLE } from "../utils/portAdvisory";

const RISK_COLOR = { Low: "#22c55e", Moderate: "#fbbf24", High: "#fb923c", Severe: "#ef4444" };
const ALL_PORTS = [...INDIAN_PORTS, ...GLOBAL_PORTS];

const VIEWS = [
  { key: "ports", label: "🎣 Global Fishing Ports" },
  { key: "zones", label: "🌊 Real-Time Risk Zones" },
];

function GlobePanel() {
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [view, setView] = useState("ports");
  const { zones, loading, lastUpdated } = useGlobalRiskZones();

  const zonePoints = useMemo(() => {
    return zones.map((z) => ({
      kind: "zone",
      name: z.name,
      lat: z.lat,
      lng: z.lon,
      risk: z.risk.label,
      score: z.risk.score,
      waveHeight: z.waveHeight,
      windSpeed: z.windSpeed,
      sst: z.seaSurfaceTemp,
      source: z.source,
      updatedAt: z.updatedAt,
      color: RISK_COLOR[z.risk.label] || "#38bdf8",
    }));
  }, [zones]);

  const portPoints = useMemo(() => {
    const annotated = annotatePorts(ALL_PORTS, zones);
    return annotated.map((p) => ({
      kind: "port",
      name: p.name,
      lat: p.lat,
      lng: p.lon,
      verdict: p.verdict,
      reason: p.reason,
      source: p.source,
      color: VERDICT_STYLE[p.verdict]?.color || "#38bdf8",
    }));
  }, [zones]);

  const pointsData = view === "ports" ? portPoints : zonePoints;

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-1">
        <div>
          <h2 className="text-3xl font-bold">🌍 Interactive Marine Globe</h2>
          <p className="text-sm text-slate-400 mt-1">
            {view === "ports"
              ? `${portPoints.length} fishing ports across every continent — rotate and click a point for its live feasibility verdict.`
              : `${zonePoints.length} live risk zones worldwide — rotate and click a point for current wave, wind and SST readings.`}
          </p>
        </div>
        <div className="flex gap-2 bg-slate-900/60 rounded-lg p-1 text-sm shrink-0">
          {VIEWS.map((v) => (
            <button
              key={v.key}
              onClick={() => {
                setView(v.key);
                setSelectedPoint(null);
              }}
              className={
                "px-3 py-1.5 rounded-md transition-colors whitespace-nowrap " +
                (view === v.key ? "bg-[#c9a962] text-[#0a141b] font-semibold" : "text-slate-300 hover:bg-slate-700")
              }
            >
              {v.label}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[700px] rounded-xl overflow-hidden bg-black mt-4">
        {loading ? (
          <div className="h-full flex items-center justify-center text-slate-400">
            Loading globe data…
          </div>
        ) : (
          <Globe
            globeImageUrl="//unpkg.com/three-globe/example/img/earth-blue-marble.jpg"
            bumpImageUrl="//unpkg.com/three-globe/example/img/earth-topology.png"
            backgroundImageUrl="//unpkg.com/three-globe/example/img/night-sky.png"
            pointsData={pointsData}
            pointLat="lat"
            pointLng="lng"
            pointColor="color"
            pointAltitude={0.02}
            pointRadius={view === "ports" ? 0.35 : 0.45}
            showAtmosphere
            atmosphereColor="lightskyblue"
            atmosphereAltitude={0.15}
            pointLabel={(d) =>
              d.kind === "port"
                ? `<div style="background:#0f172a;color:#fff;padding:8px 10px;border-radius:8px;font-size:12px;line-height:1.5;max-width:220px">
                     <b>${d.name}</b><br/>
                     ${d.verdict}<br/>
                     <span style="opacity:.8">${d.source === "live" ? "🛰️ Live zone" : "📈 Modeled"}</span>
                   </div>`
                : `<div style="background:#0f172a;color:#fff;padding:8px 10px;border-radius:8px;font-size:12px;line-height:1.5">
                     <b>${d.name}</b><br/>
                     Risk: ${d.risk} (${d.score}/100)<br/>
                     Wave: ${d.waveHeight} m · Wind: ${d.windSpeed} km/h
                   </div>`
            }
            onPointClick={(point) => setSelectedPoint(point)}
          />
        )}
      </div>

      {selectedPoint && (
        <div className="mt-6 bg-slate-700 rounded-lg p-5">
          <h3 className="text-2xl font-bold">{selectedPoint.name}</h3>

          {selectedPoint.kind === "port" ? (
            <>
              <p className="mt-3">
                <b>Verdict:</b> {selectedPoint.verdict}
              </p>
              <p className="text-sm text-slate-300 mt-1">{selectedPoint.reason}</p>
              <p className="mt-2 text-xs text-slate-400">
                {selectedPoint.source === "live" ? "🛰️ Backed by a live risk zone" : "📈 Modeled climatology estimate"}
              </p>
            </>
          ) : (
            <>
              <p className="mt-3">
                <b>Risk:</b> {selectedPoint.risk} ({selectedPoint.score}/100)
              </p>
              <p>
                <b>Wave height:</b> {selectedPoint.waveHeight} m
              </p>
              <p>
                <b>Wind speed:</b> {selectedPoint.windSpeed} km/h
              </p>
              {selectedPoint.sst != null && (
                <p>
                  <b>Sea surface temp:</b> {selectedPoint.sst}°C
                </p>
              )}
              <p className="mt-2 text-xs text-slate-400">
                {selectedPoint.source === "live" ? "🛰️ Live reading" : "📈 Modeled estimate"} · updated{" "}
                {new Date(selectedPoint.updatedAt).toLocaleTimeString()}
              </p>
            </>
          )}
          <p className="mt-1">
            <b>Latitude:</b> {selectedPoint.lat.toFixed(2)} · <b>Longitude:</b> {selectedPoint.lng.toFixed(2)}
          </p>
        </div>
      )}

      <p className="text-xs text-slate-500 mt-4">
        {view === "ports"
          ? "Every port worldwide is rated against its nearest live risk zone (or a modeled seasonal estimate when none is close enough)."
          : `Live wave, wind, swell and SST readings from Open-Meteo across every ocean basin${
              lastUpdated ? ` · last updated ${lastUpdated.toLocaleTimeString()}` : ""
            }.`}
      </p>
    </div>
  );
}

export default GlobePanel;
