import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { useGlobalRiskZones } from "../hooks/useGlobalRiskZones";

const RISK_COLORS = { Low: "#22c55e", Moderate: "#f59e0b", High: "#fb923c", Severe: "#ef4444" };

export default function ChartPanel() {
  const { zones, history, loading, lastUpdated } = useGlobalRiskZones();

  const byRegionRisk = zones.reduce((acc, z) => {
    if (!acc[z.region]) acc[z.region] = { Region: z.region, Low: 0, Moderate: 0, High: 0, Severe: 0 };
    acc[z.region][z.risk.label] += 1;
    return acc;
  }, {});
  const regionData = Object.values(byRegionRisk);

  const avgScore = zones.length ? (zones.reduce((s, z) => s + z.risk.score, 0) / zones.length).toFixed(1) : "--";
  const severeCount = zones.filter((z) => z.risk.label === "Severe" || z.risk.label === "High").length;

  if (loading) {
    return (
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
        <h2 className="text-3xl font-bold">📈 Marine Risk Analytics</h2>
        <p className="mt-4 text-slate-400">Loading live global risk data…</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
      <div className="flex flex-wrap justify-between items-center gap-3 mb-8">
        <h2 className="text-3xl font-bold">📈 Marine Risk Analytics</h2>
        <div className="flex gap-3">
          <div className="bg-[#a4823f] px-4 py-2 rounded-lg font-bold">Avg risk score: {avgScore}/100</div>
          <div className="bg-red-600/80 px-4 py-2 rounded-lg font-bold">High/Severe zones: {severeCount}</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-slate-700 rounded-xl p-5">
          <h3 className="text-xl font-semibold mb-4">Global Average Risk Score (live session trend)</h3>
          {history.length < 2 ? (
            <p className="text-sm text-slate-400 py-10 text-center">
              Collecting live samples — this chart fills in as refreshes come through.
            </p>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                <XAxis dataKey="time" stroke="#cbd5e1" />
                <YAxis stroke="#cbd5e1" domain={[0, 100]} />
                <Tooltip />
                <Line type="monotone" dataKey="avgScore" name="Avg Risk Score" stroke="#06b6d4" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-slate-700 rounded-xl p-5">
          <h3 className="text-xl font-semibold mb-4">Worst Zone Score (live session trend)</h3>
          {history.length < 2 ? (
            <p className="text-sm text-slate-400 py-10 text-center">
              Collecting live samples — this chart fills in as refreshes come through.
            </p>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                <XAxis dataKey="time" stroke="#cbd5e1" />
                <YAxis stroke="#cbd5e1" domain={[0, 100]} />
                <Tooltip />
                <Line type="monotone" dataKey="worstScore" name="Worst Zone Score" stroke="#ef4444" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-slate-700 rounded-xl p-5 md:col-span-2">
          <h3 className="text-xl font-semibold mb-4">Risk Level Distribution by Region (right now)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={regionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis dataKey="Region" stroke="#cbd5e1" interval={0} angle={-20} textAnchor="end" height={70} />
              <YAxis stroke="#cbd5e1" allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="Low" stackId="a" fill={RISK_COLORS.Low} />
              <Bar dataKey="Moderate" stackId="a" fill={RISK_COLORS.Moderate} />
              <Bar dataKey="High" stackId="a" fill={RISK_COLORS.High} />
              <Bar dataKey="Severe" stackId="a" fill={RISK_COLORS.Severe} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <p className="text-xs text-slate-500 mt-6">
        Built entirely from live readings across {zones.length} tracked ocean zones
        {lastUpdated ? ` · last updated ${lastUpdated.toLocaleTimeString()}` : ""}. Trend charts accumulate as the
        session runs since refreshes happen every 5 minutes.
      </p>
    </div>
  );
}
