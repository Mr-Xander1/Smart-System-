import { useMemo, useState } from "react";
import { ChevronDown, TrendingUp, TrendingDown, Minus, AlertTriangle } from "lucide-react";
import { useGlobalRiskZones } from "../hooks/useGlobalRiskZones";
import { labelColor } from "../utils/riskEngine";

const ACTION_BY_LABEL = {
  Low: "Routine monitoring — no action needed",
  Moderate: "Advisory issued — monitor closely",
  High: "Deploy Coast Guard Patrol",
  Severe: "Activate emergency response protocol",
};

function projectTrend(history) {
  if (history.length < 2) return { direction: "flat", delta: 0 };
  const last = history[history.length - 1];
  const prev = history[Math.max(0, history.length - 4)]; // compare against ~4 samples back
  const delta = Number((last.avgScore - prev.avgScore).toFixed(1));
  const direction = delta > 1 ? "up" : delta < -1 ? "down" : "flat";
  return { direction, delta };
}

function PredictionPanel() {
  const { zones, loading, history, lastUpdated } = useGlobalRiskZones();
  const [expanded, setExpanded] = useState(false);
  const [selectedKey, setSelectedKey] = useState(null);

  const sorted = useMemo(() => [...zones].sort((a, b) => b.risk.score - a.risk.score), [zones]);
  const worst = sorted[0];
  const selected = zones.find((z) => z.key === selectedKey) || worst;

  const trend = projectTrend(history);
  const TrendIcon = trend.direction === "up" ? TrendingUp : trend.direction === "down" ? TrendingDown : Minus;
  const trendColor = trend.direction === "up" ? "text-red-400" : trend.direction === "down" ? "text-green-400" : "text-slate-500";

  const severeCount = zones.filter((z) => z.risk.label === "Severe" || z.risk.label === "High").length;

  if (loading || !selected) {
    return (
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
        <h2 className="text-2xl font-semibold mb-6">🤖 AI Prediction Panel</h2>
        <p className="text-slate-400 text-sm">Running live prediction across all ocean zones…</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
        <h2 className="text-2xl font-semibold">🤖 AI Prediction Panel</h2>
        <select
          value={selected.key}
          onChange={(e) => setSelectedKey(e.target.value)}
          className="bg-slate-900/60 text-sm text-slate-200 rounded-lg px-3 py-1.5 border border-white/10"
        >
          {sorted.map((z) => (
            <option key={z.key} value={z.key}>
              {z.name} — {z.risk.label}
            </option>
          ))}
        </select>
      </div>

      {severeCount > 0 && (
        <div className="mb-4 flex items-center gap-2 bg-red-500/10 border border-red-500/30 text-red-300 text-sm rounded-lg px-4 py-2.5">
          <AlertTriangle size={16} /> {severeCount} zone{severeCount > 1 ? "s" : ""} worldwide currently at High/Severe risk
          {worst ? ` — worst: ${worst.name} (${worst.risk.score}/100)` : ""}.
        </div>
      )}

      <div className="space-y-4">
        <div className="bg-slate-700 rounded-lg p-4">
          <h3 className="text-gray-400 text-sm">{selected.name} — Risk Level</h3>
          <p className={`${labelColor(selected.risk.label)} text-2xl font-bold`}>
            {selected.risk.label} <span className="text-sm text-slate-400 font-normal">({selected.risk.score}/100)</span>
          </p>
        </div>

        <div className="bg-slate-700 rounded-lg p-4">
          <h3 className="text-gray-400 text-sm">AI Confidence</h3>
          <p className="text-[#c9a962] text-2xl font-bold">{selected.risk.confidence}%</p>
          <p className="text-xs text-slate-500 mt-1">
            Based on {selected.risk.breakdown.length} live factors · {selected.source === "live" ? "🛰️ live reading" : "📈 modeled estimate"}
          </p>
        </div>

        <div className="bg-slate-700 rounded-lg p-4">
          <h3 className="text-gray-400 text-sm">Global Trend (last {Math.min(history.length, 4)} updates)</h3>
          <p className={`${trendColor} text-lg font-bold flex items-center gap-2`}>
            <TrendIcon size={18} /> {trend.direction === "flat" ? "Stable" : trend.direction === "up" ? "Rising" : "Falling"}
            <span className="text-sm text-slate-400 font-normal">({trend.delta > 0 ? "+" : ""}{trend.delta} pts avg score)</span>
          </p>
        </div>

        <div className="bg-slate-700 rounded-lg p-4">
          <h3 className="text-gray-400 text-sm">Suggested Action</h3>
          <p className="text-green-400 font-semibold">{ACTION_BY_LABEL[selected.risk.label]}</p>
        </div>
      </div>

      <button
        onClick={() => setExpanded((v) => !v)}
        className="mt-4 flex items-center gap-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors"
      >
        View contributing factors
        <ChevronDown size={14} className={`transition-transform ${expanded ? "rotate-180" : ""}`} />
      </button>

      {expanded && (
        <div className="mt-4 space-y-2.5 border-t border-white/10 pt-4">
          {selected.risk.breakdown.map((f) => (
            <div key={f.key} className="flex items-center gap-3 text-sm">
              <span className="w-40 shrink-0 text-slate-400">{f.label}</span>
              <span className="w-24 shrink-0 font-mono text-slate-200">{f.value.toFixed(1)} {f.unit}</span>
              <div className="flex-1 h-2 bg-slate-900/60 rounded-full overflow-hidden">
                <div className="h-full bg-[#c9a962] rounded-full transition-all duration-700" style={{ width: `${f.contribution}%` }} />
              </div>
              <span className="w-10 text-right text-xs text-slate-400">{f.contribution}%</span>
            </div>
          ))}
        </div>
      )}

      <p className="text-xs text-slate-500 mt-4">
        Predictions run live across all {zones.length} tracked ocean zones{lastUpdated ? ` · last updated ${lastUpdated.toLocaleTimeString()}` : ""}.
      </p>
    </div>
  );
}

export default PredictionPanel;
