// ---------------------------------------------------------------------------
// Unified Port Advisory Engine
// ---------------------------------------------------------------------------
// Every port in the app (India, Global) is run through this single function.
// It prefers a REAL live reading from the nearest zone in
// hooks/useGlobalRiskZones (live Open-Meteo marine + weather data, computed
// through utils/riskEngine) when a zone is close enough; otherwise it falls
// back to the global seasonal climatology model so that ports far from a
// polled zone still get an honest, physically-motivated estimate instead of
// being left blank.
// ---------------------------------------------------------------------------
import { nearest } from "./geo";
import { estimatePortConditions } from "./marineClimatology";

export const COVERAGE_LIMIT_KM = 2200;

export const VERDICT_STYLE = {
  Favorable: {
    color: "#22c55e",
    badge: "bg-green-500/20 text-green-400 border-green-500/40",
    label: "✅ Favorable",
  },
  Caution: {
    color: "#f59e0b",
    badge: "bg-amber-500/20 text-amber-400 border-amber-500/40",
    label: "⚠️ Caution",
  },
  "Not Recommended": {
    color: "#ef4444",
    badge: "bg-red-500/20 text-red-400 border-red-500/40",
    label: "🚫 Not Recommended",
  },
  "Limited Data": {
    color: "#94a3b8",
    badge: "bg-slate-500/20 text-slate-300 border-slate-500/40",
    label: "❔ Limited Data",
  },
};

function verdictFromRisk(riskLabel, riskScore, zoneName) {
  if (riskLabel === "Severe" || riskLabel === "High") {
    return {
      verdict: "Not Recommended",
      reason: `Live conditions near ${zoneName} are rated ${riskLabel} risk (${riskScore}/100). Expect rough seas and/or an active weather system — stay ashore.`,
    };
  }
  if (riskLabel === "Moderate") {
    return {
      verdict: "Caution",
      reason: `Live conditions near ${zoneName} are rated Moderate risk (${riskScore}/100). Experienced crews only, stay close to shore.`,
    };
  }
  return {
    verdict: "Favorable",
    reason: `Live conditions near ${zoneName} are rated Low risk (${riskScore}/100). Normal fishing activity is supported.`,
  };
}

/**
 * getPortAdvisory(port, liveZones)
 * -> { verdict, reason, source: "live" | "modeled", distanceKm?, zone?, conditions, risk, ...modelFields }
 *
 * liveZones: array of zone objects from hooks/useGlobalRiskZones (each with
 * {lat, lon, name, waveHeight, windSpeed, pressureDrop, waterTemp, swellPeriod, risk}),
 * or [] if not loaded yet.
 */
export function getPortAdvisory(port, liveZones = []) {
  const model = estimatePortConditions(port.lat, port.lon);
  const modelConditions = {
    waveHeight: model.waveHeight,
    windSpeed: model.windSpeed,
    pressureDrop: model.pressureDrop,
    waterTemp: Math.abs(model.sstAnomaly),
    swellPeriod: model.swellPeriod,
  };

  if (liveZones.length) {
    const { item: zone, distanceKm } = nearest(port.lat, port.lon, liveZones);
    if (zone && distanceKm <= COVERAGE_LIMIT_KM) {
      const { verdict, reason } = verdictFromRisk(zone.risk.label, zone.risk.score, zone.name);
      return {
        ...model,
        verdict,
        reason,
        source: zone.source,
        distanceKm,
        zone,
        risk: zone.risk,
        sstAnomaly: zone.sstAnomaly,
        conditions: {
          waveHeight: zone.waveHeight,
          windSpeed: zone.windSpeed,
          pressureDrop: zone.pressureDrop,
          waterTemp: zone.waterTemp,
          swellPeriod: zone.swellPeriod,
        },
      };
    }
  }

  const fallbackLabel = model.verdict === "Not Recommended" ? "High" : model.verdict === "Caution" ? "Moderate" : "Low";
  const { verdict, reason } = verdictFromRisk(fallbackLabel, "--", "the modeled climatology estimate");

  return {
    ...model,
    verdict,
    reason: model.reason,
    source: "modeled",
    distanceKm: null,
    zone: null,
    risk: null,
    conditions: modelConditions,
  };
}

/**
 * annotatePorts(ports, liveZones) -> ports with advisory fields merged in.
 */
export function annotatePorts(ports, liveZones = []) {
  return ports.map((port) => ({ ...port, ...getPortAdvisory(port, liveZones) }));
}
