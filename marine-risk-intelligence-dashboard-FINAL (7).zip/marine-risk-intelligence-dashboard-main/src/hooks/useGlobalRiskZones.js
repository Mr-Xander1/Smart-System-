// Backward-compatible re-export: the actual live-data logic now lives in
// context/RiskZonesContext.jsx (a shared provider, so the whole app polls
// Open-Meteo once instead of every panel firing its own fetch loop).
export { useGlobalRiskZones } from "../context/RiskZonesContext";
