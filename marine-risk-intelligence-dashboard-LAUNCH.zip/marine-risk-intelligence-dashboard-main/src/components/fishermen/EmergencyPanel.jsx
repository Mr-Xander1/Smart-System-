import { useState } from "react";
import { Phone, MapPin, Radio } from "lucide-react";
import { useLanguage } from "../../context/LanguageContext";

const COAST_GUARD_HELPLINE = "1554"; // Indian Coast Guard toll-free helpline

function EmergencyPanel() {
  const { t } = useLanguage();
  const [locationText, setLocationText] = useState("");
  const [status, setStatus] = useState("idle"); // idle | locating | done | error

  const shareLocation = () => {
    if (!navigator.geolocation) {
      setStatus("error");
      setLocationText("Geolocation isn't available on this device — read your GPS coordinates to the coast guard directly.");
      return;
    }
    setStatus("locating");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setLocationText(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
        setStatus("done");
      },
      () => {
        setStatus("error");
        setLocationText("Location permission denied — read your GPS coordinates to the coast guard directly.");
      }
    );
  };

  return (
    <div className="bg-red-950/40 border border-red-500/30 rounded-xl p-6 shadow-lg">
      <h2 className="text-2xl font-semibold flex items-center gap-2 text-red-300">
        <Radio size={22} /> Emergency
      </h2>
      <p className="text-sm text-slate-300 mt-2">
        In distress at sea? Call the coast guard first, then share your exact location.
      </p>

      <div className="mt-5 flex flex-col sm:flex-row gap-3">
        <a
          href={`tel:${COAST_GUARD_HELPLINE}`}
          className="flex-1 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 transition-colors font-semibold rounded-xl px-5 py-3.5"
        >
          <Phone size={18} /> {t("emergencyCall")} ({COAST_GUARD_HELPLINE})
        </a>
        <button
          onClick={shareLocation}
          className="flex-1 flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 transition-colors font-semibold rounded-xl px-5 py-3.5"
        >
          <MapPin size={18} /> {t("shareLocation")}
        </button>
      </div>

      {status !== "idle" && (
        <div className="mt-4 bg-slate-900/60 rounded-lg p-3 text-sm">
          {status === "locating" && <span className="text-slate-400">Getting your location…</span>}
          {status === "done" && (
            <span>
              📍 Your coordinates: <span className="font-mono text-[#c9a962]">{locationText}</span> — read these out on your radio/call.
            </span>
          )}
          {status === "error" && <span className="text-yellow-400">{locationText}</span>}
        </div>
      )}
    </div>
  );
}

export default EmergencyPanel;
