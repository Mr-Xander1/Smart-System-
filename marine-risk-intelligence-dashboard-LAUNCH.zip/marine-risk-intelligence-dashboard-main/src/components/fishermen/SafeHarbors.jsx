import { Anchor, Navigation } from "lucide-react";
import { useLanguage } from "../../context/LanguageContext";

const HARBORS = [
  { name: "Sassoon Dock, Mumbai", coords: [18.9147, 72.8258], distanceKm: 12, status: "Open" },
  { name: "Kasimedu Fishing Harbour, Chennai", coords: [13.1167, 80.2989], distanceKm: 8, status: "Open" },
  { name: "Veraval Fishing Harbour, Gujarat", coords: [20.9159, 70.3629], distanceKm: 21, status: "Open" },
  { name: "Munambam Harbour, Kochi", coords: [10.1667, 76.1667], distanceKm: 15, status: "Crowded" },
];

function SafeHarbors() {
  const { t } = useLanguage();

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
      <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
        <Anchor size={22} className="text-[#c9a962]" /> {t("nearestHarbor")}
      </h2>

      <div className="space-y-3">
        {HARBORS.map((h) => (
          <div key={h.name} className="bg-slate-700 rounded-lg p-4 flex items-center justify-between gap-4">
            <div>
              <div className="font-medium">{h.name}</div>
              <div className="text-xs text-slate-400 mt-1">
                {h.distanceKm} km away ·{" "}
                <span className={h.status === "Open" ? "text-green-400" : "text-yellow-400"}>{h.status}</span>
              </div>
            </div>
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${h.coords[0]},${h.coords[1]}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 text-[#c9a962] text-sm font-medium hover:text-[#dcc07f] shrink-0"
            >
              <Navigation size={15} /> Directions
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SafeHarbors;
