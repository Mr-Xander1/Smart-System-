import { useState } from "react";
import { useLiveMarineData, BASELINES } from "../hooks/useLiveMarineData";
import { useLanguage } from "../context/LanguageContext";
import SafetyVerdict from "../components/fishermen/SafetyVerdict";
import FishingZoneMap from "../components/fishermen/FishingZoneMap";
import SafeHarbors from "../components/fishermen/SafeHarbors";
import CatchAndCostPanel from "../components/fishermen/CatchAndCostPanel";
import EmergencyPanel from "../components/fishermen/EmergencyPanel";
import Footer from "../components/Footer";

const ZONE_LABELS = { mumbai: "Mumbai", chennai: "Chennai", surat: "Surat", kochi: "Kochi" };

function FishermenZone() {
  const [zone, setZone] = useState("mumbai");
  const { data } = useLiveMarineData(zone);
  const { t } = useLanguage();

  return (
    <div className="flex flex-col min-h-screen">
      <div className="p-6 sm:p-8 max-w-6xl mx-auto flex-1 w-full">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold">🎣 {t("fishermenZone")}</h1>
          <p className="mt-2 text-gray-400">Live safety advisory, fishing zones, and trip planning — built for small-boat crews.</p>
        </div>

        <div className="flex gap-2 bg-slate-800 rounded-xl p-1">
          {Object.keys(BASELINES).map((key) => (
            <button
              key={key}
              onClick={() => setZone(key)}
              className={
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors " +
                (zone === key ? "bg-[#c9a962] text-[#0a141b]" : "text-slate-300 hover:bg-slate-700")
              }
            >
              {ZONE_LABELS[key]}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <SafetyVerdict liveData={data} />
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CatchAndCostPanel liveData={data} />
        <SafeHarbors />
      </div>

      <div className="mt-8">
        <FishingZoneMap />
      </div>

      <div className="mt-8">
        <EmergencyPanel />
      </div>
      </div>
      <Footer />
    </div>
  );
}

export default FishermenZone;
