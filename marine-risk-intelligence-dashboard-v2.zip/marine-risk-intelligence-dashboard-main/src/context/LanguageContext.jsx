import { createContext, useContext, useState } from "react";

// Small, inline translation dictionary — deliberately not a full i18n
// library, since only the safety-critical, fisherman-facing strings need
// translation right now. Add more keys/languages here as needed; anything
// missing for the active language silently falls back to English.
const DICTIONARY = {
  en: {
    langName: "English",
    safeToFish: "Safe to go fishing today?",
    go: "Go",
    caution: "Caution",
    doNotGo: "Do Not Go",
    confidence: "Confidence",
    nearestHarbor: "Nearest safe harbor",
    emergencyCall: "Call Coast Guard",
    shareLocation: "Share my location",
    tripCalculator: "Trip cost calculator",
    catchPotential: "Catch potential",
    windSpeed: "Wind speed",
    waveHeight: "Wave height",
    fishermenZone: "Fishermen Zone",
    heroTitle: "See coastal danger before it reaches shore",
    forFishermen: "Built for fishermen, port authorities, and coast guard teams",
  },
  hi: {
    langName: "हिन्दी",
    safeToFish: "आज मछली पकड़ने जाना सुरक्षित है?",
    go: "जाएँ",
    caution: "सावधानी",
    doNotGo: "न जाएँ",
    confidence: "विश्वास स्तर",
    nearestHarbor: "निकटतम सुरक्षित बंदरगाह",
    emergencyCall: "कोस्ट गार्ड को कॉल करें",
    shareLocation: "अपना स्थान साझा करें",
    tripCalculator: "यात्रा लागत कैलकुलेटर",
    catchPotential: "मछली पकड़ने की संभावना",
    windSpeed: "हवा की गति",
    waveHeight: "लहर की ऊँचाई",
    fishermenZone: "मछुआरा क्षेत्र",
    heroTitle: "तट पर खतरा पहुँचने से पहले ही देखें",
    forFishermen: "मछुआरों, बंदरगाह अधिकारियों और कोस्ट गार्ड के लिए बनाया गया",
  },
  ta: {
    langName: "தமிழ்",
    safeToFish: "இன்று மீன் பிடிக்க செல்வது பாதுகாப்பானதா?",
    go: "செல்லுங்கள்",
    caution: "எச்சரிக்கை",
    doNotGo: "செல்ல வேண்டாம்",
    confidence: "நம்பிக்கை நிலை",
    nearestHarbor: "அருகிலுள்ள பாதுகாப்பான துறைமுகம்",
    emergencyCall: "கடலோர காவல்படையை அழைக்கவும்",
    shareLocation: "எனது இருப்பிடத்தைப் பகிரவும்",
    tripCalculator: "பயண செலவு கால்குலேட்டர்",
    catchPotential: "மீன் பிடிப்பு வாய்ப்பு",
    windSpeed: "காற்றின் வேகம்",
    waveHeight: "அலை உயரம்",
    fishermenZone: "மீனவர் மண்டலம்",
    heroTitle: "கடற்கரையை அபாயம் அடையும் முன் காணுங்கள்",
    forFishermen: "மீனவர்கள், துறைமுக அதிகாரிகள் மற்றும் கடலோர காவல்படைக்காக உருவாக்கப்பட்டது",
  },
};

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState("en");

  const t = (key) => DICTIONARY[lang]?.[key] ?? DICTIONARY.en[key] ?? key;

  return (
    <LanguageContext.Provider value={{ lang, setLang, t, languages: Object.keys(DICTIONARY), DICTIONARY }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
