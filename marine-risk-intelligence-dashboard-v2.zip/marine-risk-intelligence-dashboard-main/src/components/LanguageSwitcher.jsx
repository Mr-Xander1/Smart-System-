import { useState } from "react";
import { Globe } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

function LanguageSwitcher() {
  const { lang, setLang, languages, DICTIONARY } = useLanguage();
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg hover:bg-white/10 transition-colors text-sm"
        aria-label="Change language"
      >
        <Globe size={17} />
        <span className="hidden sm:inline">{DICTIONARY[lang].langName}</span>
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-2 w-36 bg-slate-800 border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden">
            {languages.map((code) => (
              <button
                key={code}
                onClick={() => { setLang(code); setOpen(false); }}
                className={
                  "w-full text-left px-4 py-2.5 text-sm transition-colors " +
                  (code === lang ? "bg-cyan-400/10 text-cyan-300" : "hover:bg-white/5")
                }
              >
                {DICTIONARY[code].langName}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default LanguageSwitcher;
