import { useMemo, useState } from "react";
import { Fish, Fuel, IndianRupee } from "lucide-react";
import { useLanguage } from "../../context/LanguageContext";

// Simple, explainable catch-potential proxy: warmer-but-not-too-warm water
// plus calmer seas historically correlates with better nearshore catch.
// This is a heuristic stand-in for a real chlorophyll/SST fisheries model —
// documented here so it's obvious what to replace later.
function estimateCatchPotential({ waterTemp, waveHeight }) {
  const tempScore = Math.max(0, 100 - Math.abs(waterTemp - 1.2) * 40); // sweet spot around +1.2°C anomaly
  const calmScore = Math.max(0, 100 - waveHeight * 18);
  const score = Math.round(tempScore * 0.55 + calmScore * 0.45);
  let label = "Low";
  if (score > 70) label = "High";
  else if (score > 40) label = "Moderate";
  return { score: Math.min(100, score), label };
}

function CatchAndCostPanel({ liveData }) {
  const { t } = useLanguage();
  const [distance, setDistance] = useState(15);
  const [fuelPricePerL, setFuelPricePerL] = useState(95);
  const [boatEfficiency, setBoatEfficiency] = useState(4); // km per litre
  const [expectedCatchKg, setExpectedCatchKg] = useState(25);
  const [pricePerKg, setPricePerKg] = useState(180);

  const catchPotential = estimateCatchPotential(liveData);

  const { fuelCost, catchValue, profit } = useMemo(() => {
    const roundTrip = distance * 2;
    const litres = roundTrip / Math.max(boatEfficiency, 0.5);
    const fuelCost = litres * fuelPricePerL;
    const catchValue = expectedCatchKg * pricePerKg;
    return { fuelCost, catchValue, profit: catchValue - fuelCost };
  }, [distance, fuelPricePerL, boatEfficiency, expectedCatchKg, pricePerKg]);

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg space-y-6">
      <div>
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <Fish size={22} className="text-cyan-400" /> {t("catchPotential")}
        </h2>
        <div className="mt-4 flex items-center gap-4">
          <div className="text-4xl font-bold text-cyan-300">{catchPotential.score}</div>
          <div>
            <div className="font-semibold">{catchPotential.label}</div>
            <div className="text-xs text-slate-400">Based on sea temperature + wave calmness</div>
          </div>
        </div>
        <div className="mt-3 h-2 bg-slate-900/60 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-full transition-all duration-700" style={{ width: `${catchPotential.score}%` }} />
        </div>
      </div>

      <div className="border-t border-white/5 pt-5">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Fuel size={18} className="text-cyan-400" /> {t("tripCalculator")}
        </h3>

        <div className="mt-4 grid sm:grid-cols-2 gap-4">
          <label className="text-sm text-slate-300">
            Distance to fishing zone (km)
            <input type="range" min="2" max="60" value={distance} onChange={(e) => setDistance(Number(e.target.value))} className="w-full mt-2 accent-cyan-400" />
            <span className="text-cyan-300 font-mono text-sm">{distance} km</span>
          </label>

          <label className="text-sm text-slate-300">
            Boat fuel efficiency (km/litre)
            <input type="range" min="1" max="10" step="0.5" value={boatEfficiency} onChange={(e) => setBoatEfficiency(Number(e.target.value))} className="w-full mt-2 accent-cyan-400" />
            <span className="text-cyan-300 font-mono text-sm">{boatEfficiency} km/L</span>
          </label>

          <label className="text-sm text-slate-300">
            Fuel price (₹/litre)
            <input type="number" value={fuelPricePerL} onChange={(e) => setFuelPricePerL(Number(e.target.value))} className="w-full mt-2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-sm" />
          </label>

          <label className="text-sm text-slate-300">
            Expected catch (kg)
            <input type="number" value={expectedCatchKg} onChange={(e) => setExpectedCatchKg(Number(e.target.value))} className="w-full mt-2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-sm" />
          </label>

          <label className="text-sm text-slate-300 sm:col-span-2">
            Market price (₹/kg)
            <input type="number" value={pricePerKg} onChange={(e) => setPricePerKg(Number(e.target.value))} className="w-full mt-2 bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-sm" />
          </label>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-3 text-center">
          <div className="bg-slate-900/60 rounded-lg p-3">
            <div className="text-xs text-slate-400">Fuel cost</div>
            <div className="text-lg font-bold text-orange-400 flex items-center justify-center gap-0.5">
              <IndianRupee size={14} />{fuelCost.toFixed(0)}
            </div>
          </div>
          <div className="bg-slate-900/60 rounded-lg p-3">
            <div className="text-xs text-slate-400">Catch value</div>
            <div className="text-lg font-bold text-cyan-300 flex items-center justify-center gap-0.5">
              <IndianRupee size={14} />{catchValue.toFixed(0)}
            </div>
          </div>
          <div className="bg-slate-900/60 rounded-lg p-3">
            <div className="text-xs text-slate-400">Est. profit</div>
            <div className={`text-lg font-bold flex items-center justify-center gap-0.5 ${profit >= 0 ? "text-green-400" : "text-red-400"}`}>
              <IndianRupee size={14} />{profit.toFixed(0)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CatchAndCostPanel;
