import { Fragment } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { computeRisk, labelColor } from "../../utils/riskEngine";
import { BASELINES } from "../../hooks/useLiveMarineData";

const ZONE_META = {
  mumbai: { name: "Mumbai Coast", coords: [19.076, 72.8777] },
  chennai: { name: "Chennai Coast", coords: [13.0827, 80.2707] },
  surat: { name: "Surat Coast", coords: [21.1702, 72.8311] },
  kochi: { name: "Kochi Coast", coords: [9.9312, 76.2673] },
};

const CIRCLE_COLOR = { Low: "#4ade80", Moderate: "#facc15", High: "#fb923c", Severe: "#ef4444" };

function FishingZoneMap() {
  const zones = Object.keys(ZONE_META).map((key) => {
    const risk = computeRisk(BASELINES[key]);
    return { key, ...ZONE_META[key], risk };
  });

  return (
    <div className="bg-slate-800 rounded-xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-semibold">🎣 Fishing Zone Map</h2>
        <div className="flex gap-3 text-xs">
          {Object.entries(CIRCLE_COLOR).map(([label, color]) => (
            <span key={label} className="flex items-center gap-1.5 text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
              {label}
            </span>
          ))}
        </div>
      </div>

      <MapContainer center={[16, 76]} zoom={5} style={{ height: "420px", width: "100%", borderRadius: "12px" }}>
        <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {zones.map((z) => (
          <Fragment key={z.key}>
            <Circle
              center={z.coords}
              radius={45000}
              pathOptions={{ color: CIRCLE_COLOR[z.risk.label], fillColor: CIRCLE_COLOR[z.risk.label], fillOpacity: 0.35 }}
            />
            <Marker position={z.coords}>
              <Popup>
                <b>{z.name}</b>
                <br />
                Risk: <span className={labelColor(z.risk.label)}>{z.risk.label}</span> ({z.risk.score}/100)
                <br />
                Confidence: {z.risk.confidence}%
              </Popup>
            </Marker>
          </Fragment>
        ))}
      </MapContainer>

      <p className="text-xs text-slate-500 mt-3">
        Zones are colored by live composite risk score — green circles are currently the safest areas to fish.
      </p>
    </div>
  );
}

export default FishingZoneMap;
