import { useState } from "react";
import { NavLink } from "react-router-dom";
import { Menu, X, Fish } from "lucide-react";
import AlertBell from "./AlertBell";
import LanguageSwitcher from "./LanguageSwitcher";

const LINKS = [
  { to: "/", label: "Home", end: true },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/fishermen", label: "Fishermen Zone", highlight: true },
  { to: "/history", label: "History" },
  { to: "/configuration", label: "Configuration" },
  { to: "/reports", label: "Reports" },
  { to: "/account", label: "Account" },
  { to: "/submit-report", label: "Submit Report" },
  { to: "/ai-assistant", label: "AI Assistant" },
  { to: "/help-desk", label: "Help Desk" },
  { to: "/circuit-diagram", label: "Circuit" },
  { to: "/api-docs", label: "API Docs" },
  { to: "/system-about", label: "About" },
];

function Navbar() {
  const [open, setOpen] = useState(false);

  const linkClass = (highlight) => ({ isActive }) =>
    "text-sm transition duration-200 whitespace-nowrap " +
    (isActive
      ? "text-cyan-400 font-bold"
      : highlight
      ? "text-emerald-300 font-semibold hover:text-emerald-200"
      : "text-white hover:text-cyan-400");

  return (
    <nav className="sticky top-0 z-50 bg-slate-800/95 backdrop-blur border-b border-white/5 text-white px-4 sm:px-8 py-3.5 flex items-center justify-between shadow-lg">
      <NavLink to="/" className="text-xl sm:text-2xl font-bold shrink-0 flex items-center gap-1.5">
        🌊 <span className="hidden xs:inline">Marine Intelligence</span>
      </NavLink>

      {/* Desktop links */}
      <div className="hidden lg:flex gap-5 text-sm items-center overflow-x-auto">
        {LINKS.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end} className={linkClass(l.highlight)}>
            {l.highlight && <Fish size={14} className="inline mr-1 -mt-0.5" />}
            {l.label}
          </NavLink>
        ))}
      </div>

      <div className="flex items-center gap-1.5">
        <LanguageSwitcher />
        <AlertBell />
        <button className="lg:hidden p-2 rounded-lg hover:bg-white/10" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="absolute top-full left-0 right-0 lg:hidden bg-slate-800 border-b border-white/5 flex flex-col px-6 py-4 gap-3.5 max-h-[70vh] overflow-y-auto">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={linkClass(l.highlight)} onClick={() => setOpen(false)}>
              {l.highlight && <Fish size={14} className="inline mr-1 -mt-0.5" />}
              {l.label}
            </NavLink>
          ))}
        </div>
      )}
    </nav>
  );
}

export default Navbar;
